�
Language0�Language1
Conveyor1�Conveyor1
Conveyor2�Conveyor2
Conveyor3�Conveyor3
conveyor1�conveyor1
conveyor2�conveyor2
conveyor3�conveyor3
sensor1�sensor1
sensor2�sensor2
STOP 1�STOP 1
Conveyor 1 overloaded!�Conveyor 1 overloaded!
Conveyor 2 Overload!�Conveyor 2 Overload!
Alarms�Alarms
Active�Active
Ack�Ack
Message�Message
Date�Date
Time�Time
Class 1�Class 1
Class 2�Class 2
To ack�To ack
Excluded�Excluded
Alarm History�Alarm History
Start date�Start date
Start time�Start time
End date�End date
End time�End time
Conveyor 1 switched on.�Conveyor 1 switched on.
Conveyor 2 switched on.�Conveyor 2 switched on.
Events�Events
Close�Close
close�close
Button�Button
Blink ON�Blink ON
Blink OFF�Blink OFF
ALARM: Workpiece idle on M1a > 10s�ALARM: Workpiece idle on M1a > 10s
ALARM: Workpiece idle on M1b > 10s�ALARM: Workpiece idle on M1b > 10s
ALARM: Workpiece idle on M1c > 10s�ALARM: Workpiece idle on M1c > 10s
M1a machine started�M1a machine started
M1a machine stopped�M1a machine stopped
M1b machine started�M1b machine started
M1b machine stopped�M1b machine stopped
M1c machine started�M1c machine started
M1c machine stopped�M1c machine stopped
M1a tool change started�M1a tool change started
M1b tool change started�M1b tool change started
M1c tool change started�M1c tool change started
Input_conveyor�Input_conveyor
M1a�M1a
Input�Input
Linear 1�Linear 1
M1b�M1b
Linear 2�Linear 2
M1c�M1c
Output�Output
T1�T1
T2�T2
T3�T3
Changing Tool�Changing Tool
Idle�Idle
T8�T8
T9�T9
T11�T11
Automatic�Automatic
Manual�Manual
Maintenance�Maintenance
ALARM: Workpiece idle - M1a!�ALARM: Workpiece idle - M1a!
ALARM: Workpiece idle - M1b!�ALARM: Workpiece idle - M1b!
ALARM: Workpiece idle - M1c!�ALARM: Workpiece idle - M1c!
Machine Power�Machine Power
Tool Swap�Tool Swap
Op. Finished�Op. Finished
